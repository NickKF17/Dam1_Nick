package def;

import java.util.HashSet;
import java.util.*;
public class Proyecto {
	private String nombre;
	private Jefes_Proyect jefe;
	private ArrayList<Programador> programadores =new ArrayList<>();
	private String maxemple=null;
	private String descripcion;
public Proyecto(String nom,Jefes_Proyect jefe,String desc,String maxemp) {
	this.nombre=asignarproye();
	this.descripcion=desc;
	this.maxemple=maxemp;
	this.jefe=jefe;
}
public void ListarProyecto() {
	System.out.println("Proyecto: "+this.nombre+".  "+this.descripcion+"\nJefe de Proyectos: "+this.jefe.getCodigo()+". "+this.jefe.getNombre()
	+"\nDesarrolladores asignados:");
	for(Programador pre:programadores)
		System.out.println(pre.getCodigo()+". "+pre.getNombre());
}

public static String asignarproye() {
	String code="";
	HashSet<String>proyectos=new HashSet<>();
	int i=0;
	boolean acabo=false;
do {
	code="PRO-"+i;
	if(proyectos.add(code)==true) {
	acabo=true;
	}
	else
	i++;

}while (acabo=false);

return code;
}
public void cambiarjefe(Jefes_Proyect jefe) {
	this.jefe=jefe;
	System.out.println("El Jefe del Proyecto "+this.nombre+" ha cambiado. Ahora es "+jefe.getNombre());
}
public void asignarProgramador(Programador p) {
	int maximo=Integer.parseInt(this.maxemple);
	if(this.maxemple==null)
		System.out.println("No se puede asignar a "+p.getNombre()+" al proyecto "+this.nombre+". No tiene aun definido al numero de desarrolladores");
	if(programadores.size()<maximo) {
	programadores.add(p);
	System.out.println(p.getNombre()+" asignado al proyecto "+this.nombre);
	}
	else
		System.out.println("No se puede asignar a "+p.getNombre()+" al proyecto "+ this.nombre+". Maximo de desarroladores cubierto");
	
}
public void asignarmaximo(String num) {
	if(this.maxemple==null)
		this.maxemple=num;
	else 
		System.out.println("Ya hay "+this.maxemple+" Desarrolladores asignados al proyecto "+this.nombre+". Este dato no puede cambiarse");
}
}
