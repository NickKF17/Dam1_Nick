/**
 * 
 */
/**
 * 
 */
module Examen2Tri {
}