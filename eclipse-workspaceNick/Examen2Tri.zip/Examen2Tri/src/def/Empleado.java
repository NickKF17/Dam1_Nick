package def;
import java.util.*;
abstract class Empleado {
protected String nombre;
protected String codigo;
protected double salario;

	public Empleado(String nom,String codigo,double sala){
		this.nombre=nom;
		this.codigo=codigo;
		this.salario=sala;
	}
	

public static String asignarcode() {
	String code="";
	HashSet<String>codigos=new HashSet<>();
	int i=0;
	boolean acabo=false;
do {
	code="EMP-"+i;
	if(codigos.add(code)==true) {
	acabo=true;
	}
	else
	i++;

}while (acabo=false);

return code;
}
public String getNombre() {
	return this.nombre;
}
public String getCodigo() {
	return this.codigo;
}
}
class Programador extends Empleado{
	private boolean java;
	private boolean python;
	public Programador(String nom,String codigo,double sala,boolean java,boolean python){
		super(nom,codigo,sala);
this.java=java;
this.python=python;
		this.codigo=asignarcode();
	}
	
	public void mostrar() {
		if (this.java==true & this.python==true)
			System.out.println(this.nombre+".  Codigo  "+this.codigo+"   Lenguajes de programacion: Java y Python" + " Salario Base: "+this.salario+"€");
		if(this.java==true & this.python==false)
		System.out.println(this.nombre+".  Codigo  "+this.codigo+"   Lenguajes de programacion: Java" + " Salario Base: "+this.salario+"€");
		if(this.java==false & this.python==true)
		System.out.println(this.nombre+".  Codigo  "+this.codigo+"   Lenguajes de programacion: Python" + " Salario Base: "+this.salario+"€");
		if(this.java==false & this.python==false)
			System.out.println(this.nombre+".  Codigo  "+this.codigo+"   Lenguajes de programacion: Ninguno" + " Salario Base: "+this.salario+"€");
			
	}
}

class Jefes_Proyect extends Empleado{
	
public Jefes_Proyect(String nom,String codigo,double sala) {
	super(nom,codigo,sala);
	this.codigo=asignarcode();
	}
public void mostrar() {
	System.out.println(this.nombre+".  Codigo  "+this.codigo+" Salario Base: "+this.salario+"€");
}
}
